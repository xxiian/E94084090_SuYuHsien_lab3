import pygame
import math
import os
from settings import LPATH,RPATH   #LPATH=左路徑，RPATH=右路徑

pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))

class Enemy:
    def __init__(self,road):   #road:控制路徑的參數 #road=0->LPATH,road=1->RPATH
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        self.path = [LPATH,RPATH]   #LPATH和RPATH皆為list
        self.path_pos = 0       #路徑的元素位置
        self.move_count = 0     #移動計數
        self.stride = 1         #步伐
        self.idx = road      #self.path的index
        self.x, self.y = self.path[self.idx][0]   #左或右路徑的第一個元素


    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    def draw_health_bar(self, win):
        """
        Draw health bar on an enemy
        :param win: window
        :return: None
        """
        pygame.draw.rect(win,(255,0,0),[self.x-15,self.y-30,self.max_health*3,4])
        pygame.draw.rect(win,(0,255,0),[self.x-15,self.y-30,self.health*3,4])

    def move(self):
        """
        Enemy move toward path points every frame
        :return: None
        """
        ax, ay = self.path[self.idx][self.path_pos]  #起點A
        bx, by = self.path[self.idx][self.path_pos+1]  #終點B
        distance_a_b = math.sqrt((ax - bx) ** 2 + (ay - by) ** 2) #A.B兩點間的距離
        max_count = int(distance_a_b / self.stride) # total footsteps that needed from A to B

        if self.move_count < max_count:
            unit_vector_x = (bx - ax) / distance_a_b #x的單位向量
            unit_vector_y = (by - ay) / distance_a_b #y的單位向量
            delta_x = unit_vector_x * self.stride
            delta_y = unit_vector_y * self.stride

            # update the coordinate and the counter
            self.x += delta_x
            self.y += delta_y
            self.move_count += 1
        else:
            self.move_count=0
            self.path_pos+=1

class EnemyGroup:
    def __init__(self):
        self.gen_count = 0  #self.reserved_members的元素位置
        self.gen_period = 120   # (unit: frame)
        self.period = 0  #campaign()經過幾個frame
        self.reserved_members = []  #存放Enemy()的list
        self.expedition = []  # don't change this line until you do the EX.3
        self.counter=0  #判斷左右路徑 #預設為左路徑

    def campaign(self):
        """
        Send an enemy to go on an expedition once 120 frame
        :return: None
        """
        # Hint: self.expedition.append(self.reserved_members.pop())
        self.period+=1
        if self.gen_count<3 and self.period==self.gen_period:
            if self.is_empty()==False:          #self.reserved_members不是空的list
                self.expedition.append(self.reserved_members.pop()) #將從self.reserved_members取出的Enemy()放入self.expedition
                self.gen_count+=1
                self.period=0

    def generate(self, num):
        """
        Generate the enemies in this wave
        :param num: enemy number
        :return: None
        """
        for i in range(num):
            self.reserved_members.append(Enemy(self.counter)) #將產生的Enemy()放入self.reserved_members
        if self.counter==0:  #當按下n鍵切換左右路徑
            self.counter=1
        else:
            self.counter=0
        self.period=0
        self.gen_count=0



    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)





